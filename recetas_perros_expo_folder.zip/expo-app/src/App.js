import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Home from './screens/Home';
import Profiles from './screens/Profiles';
import Planner from './screens/Planner';
import ChefMode from './screens/ChefMode';
import Recipes from './screens/Recipes';
import Chat from './screens/Chat';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="Profiles" component={Profiles} options={{ title: 'Perfiles de Mascotas' }} />
        <Stack.Screen name="Planner" component={Planner} options={{ title: 'Planificador Semanal' }} />
        <Stack.Screen name="ChefMode" component={ChefMode} options={{ title: 'Modo Chef Canino' }} />
        <Stack.Screen name="Recipes" component={Recipes} options={{ title: 'Recetas' }} />
        <Stack.Screen name="Chat" component={Chat} options={{ title: 'Chat IA' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
