const BAD = ['chocolate','uvas','cebolla','ajo','xilitol','alcohol','cafeina','pasas','nuez moscada'];

const BASES = [
  { title: 'Arroz con pavo', ingredients: ['arroz', 'pavo', 'zanahoria', 'calabacín'], method: 'Cocer arroz y pavo; mezclar con verduras cocidas.' },
  { title: 'Patata y merluza', ingredients: ['patata', 'merluza', 'guisantes'], method: 'Cocer patata y merluza; añadir guisantes al vapor.' },
  { title: 'Avena con pollo', ingredients: ['avena', 'pollo', 'calabaza'], method: 'Guisar pollo, cocer calabaza y mezclar con avena cocida.' },
  { title: 'Pasta integral con ternera', ingredients: ['pasta integral', 'ternera magra', 'zanahoria'], method: 'Hervir pasta y saltear ternera; unir con zanahoria cocida.' }
];

export function generateRecipe(pet) {
  const w = Math.max(1, Number(pet?.weightKg || 10));
  const kcal = Math.round(55 * w);
  const base = BASES[Math.floor(Math.random() * BASES.length)];

  const allergies = (pet?.allergies || []).map(a => a.toLowerCase());
  const safeIngredients = base.ingredients.filter(i => {
    const low = i.toLowerCase();
    if (BAD.some(b => low.includes(b))) return false;
    if (allergies.some(a => low.includes(a))) return false;
    return true;
  });

  return {
    title: base.title,
    kcal,
    ingredients: safeIngredients,
    method: base.method,
    note: 'Consulta a tu veterinario para dietas terapéuticas. Evita ingredientes peligrosos.'
  };
}
