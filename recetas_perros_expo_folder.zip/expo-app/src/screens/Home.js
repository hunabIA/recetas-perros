import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Recetas para Perros</Text>
      <Text style={styles.subtitle}>Demo en Expo</Text>
      <View style={styles.buttons}><Button title="Perfiles" onPress={() => navigation.navigate('Profiles')} /></View>
      <View style={styles.buttons}><Button title="Planificador" onPress={() => navigation.navigate('Planner')} /></View>
      <View style={styles.buttons}><Button title="Modo Chef" onPress={() => navigation.navigate('ChefMode')} /></View>
      <View style={styles.buttons}><Button title="Recetas" onPress={() => navigation.navigate('Recipes')} /></View>
      <View style={styles.buttons}><Button title="Chat IA" onPress={() => navigation.navigate('Chat')} /></View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 16 },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 6 },
  subtitle: { fontSize: 16, marginBottom: 20, textAlign: 'center' },
  buttons: { width: '80%', marginVertical: 6 }
});
