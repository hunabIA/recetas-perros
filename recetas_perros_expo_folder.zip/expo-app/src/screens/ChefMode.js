import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { generateRecipe } from '../utils/recipes';

export default function ChefMode() {
  const [step, setStep] = useState(0);
  const [current, setCurrent] = useState(null);

  const start = () => {
    const demoPet = { weightKg: 10, allergies: [] };
    const r = generateRecipe(demoPet);
    setCurrent(r);
    setStep(0);
  };

  if (!current) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Modo Chef Canino</Text>
        <Text>Guía paso a paso para cocinar una receta segura.</Text>
        <Button title="Empezar" onPress={start} />
      </View>
    );
  }

  const steps = [
    `Reúne ingredientes: ${current.ingredients.join(', ')}`,
    `Cocina base: ${current.method}`,
    'Deja templar y sirve en ración adecuada.',
  ];
  const next = () => setStep(s => Math.min(s + 1, steps.length - 1));

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{current.title}</Text>
      <Text style={{marginVertical: 8}}>{steps[step]}</Text>
      <Button title="Siguiente" onPress={next} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 8 }
});
