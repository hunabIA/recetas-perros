import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

const store = { recipes: [] };

export default function Recipes() {
  const data = store.recipes?.length ? store.recipes : [];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Recetas</Text>
      {data.length === 0 ? (
        <Text>No hay recetas. Genera un plan semanal en el Planificador.</Text>
      ) : (
        <FlatList
          data={data}
          keyExtractor={(item, idx) => String(idx)}
          renderItem={({item}) => (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Día {item.day}: {item.recipe.title}</Text>
              <Text style={styles.small}>Ingredientes: {item.recipe.ingredients.join(', ')}</Text>
              <Text style={styles.small}>Método: {item.recipe.method}</Text>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 8 },
  card: { padding: 12, borderWidth: 1, borderColor: '#ddd', borderRadius: 8, marginBottom: 10 },
  cardTitle: { fontWeight: 'bold', marginBottom: 4 },
  small: { fontSize: 12 }
});
