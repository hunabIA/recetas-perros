import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView } from 'react-native';

function fakeAssistant(prompt) {
  if (prompt.toLowerCase().includes('pollo')) {
    return 'Para perros, el pollo cocido sin sal ni huesos es aceptable en raciones moderadas.';
  }
  return 'En la versión con IA real, aquí verías una respuesta personalizada.';
}

export default function Chat() {
  const [text, setText] = useState('');
  const [messages, setMessages] = useState([]);

  const send = () => {
    if (!text.trim()) return;
    const userMsg = { role: 'user', content: text.trim() };
    const reply = { role: 'assistant', content: fakeAssistant(text.trim()) };
    setMessages(m => [...m, userMsg, reply]);
    setText('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Chat IA (demo)</Text>
      <ScrollView style={{flex: 1}}>
        {messages.map((m, i) => (
          <Text key={i} style={{marginVertical: 4}}>
            <Text style={{fontWeight: 'bold'}}>{m.role === 'user' ? 'Tú: ' : 'IA: '}</Text>
            {m.content}
          </Text>
        ))}
      </ScrollView>
      <TextInput style={styles.input} placeholder="Escribe tu mensaje..." value={text} onChangeText={setText} />
      <Button title="Enviar" onPress={send} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 8 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, borderRadius: 6, marginVertical: 8 }
});
