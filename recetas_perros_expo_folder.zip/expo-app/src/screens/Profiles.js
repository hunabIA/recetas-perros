import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const store = { pet: null };

export default function Profiles({ navigation }) {
  const [name, setName] = useState(store.pet?.name || '');
  const [breed, setBreed] = useState(store.pet?.breed || '');
  const [weightKg, setWeightKg] = useState(String(store.pet?.weightKg || ''));
  const [allergies, setAllergies] = useState((store.pet?.allergies || []).join(', '));

  const save = () => {
    store.pet = {
      name: name.trim(),
      breed: breed.trim(),
      weightKg: Number(weightKg) || 0,
      allergies: allergies.split(',').map(s => s.trim()).filter(Boolean)
    };
    alert('Perfil guardado');
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Perfil de mascota</Text>
      <TextInput style={styles.input} placeholder="Nombre" value={name} onChangeText={setName} />
      <TextInput style={styles.input} placeholder="Raza" value={breed} onChangeText={setBreed} />
      <TextInput style={styles.input} placeholder="Peso (kg)" value={weightKg} onChangeText={setWeightKg} keyboardType="numeric" />
      <TextInput style={styles.input} placeholder="Alergias (coma separado)" value={allergies} onChangeText={setAllergies} />
      <Button title="Guardar" onPress={save} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 12 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, borderRadius: 6, marginBottom: 10 }
});
