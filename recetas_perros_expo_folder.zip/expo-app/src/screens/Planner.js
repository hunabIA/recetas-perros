import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { generateRecipe } from '../utils/recipes';

const store = { pet: null, recipes: [] };

export default function Planner() {
  const createWeek = () => {
    if (!store.pet) return alert('Crea primero el perfil de tu mascota (en Perfiles) y vuelve.');
    store.recipes = Array.from({ length: 7 }).map((_, i) => ({
      day: i + 1,
      recipe: generateRecipe(store.pet)
    }));
    alert('Plan semanal creado');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Planificador semanal</Text>
      <Text>Genera 7 recetas adaptadas al perfil.</Text>
      <Button title="Generar plan" onPress={createWeek} />
      <Text style={{marginTop: 12}}>Ve a "Recetas" para ver el resultado.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 8 }
});
