# expo-app (Recetas Perros)

**Cómo ejecutar**
```bash
npm install
npx expo install
npx expo start
```
Escanea el QR con **Expo Go**.

**Qué incluye**
- Navegación (stack)
- Pantallas: Home, Perfiles, Planificador, Modo Chef, Recetas, Chat (stub)
- Generador simple de recetas con filtro básico de ingredientes peligrosos y alergias

**Siguiente**
- Añadir AsyncStorage para persistir
- Conectar IA real desde backend seguro
- Añadir pantallas legales (GDPR)
